# Hybrid KG Runtime v5a / Design-8a

Design-8a is a narrow safety correction to Design-8 secondary-SCR promotion.

Invariant introduced:
- Explicitly negated/excluded facets are exclusion evidence only.
- A negated facet MUST NOT generate or strengthen positive secondary promotion.
- If a secondary candidate specifically matches a negated facet, that candidate is vetoed from promotion even when semantic/context similarity is high.
- Primary Top-1 ranking is deliberately unchanged in Design-8a.

The runtime exposes `Negative_Promotion_Facets_JSON`, `Negation_Vetoed_SCR_IDs`, and per-candidate negation-veto trace fields for audit.

This correction is generic and polarity-based; it contains no benchmark-case IDs or gold labels.
