#!/usr/bin/env python3
"""Design-8 evaluator for the frozen 52-unit / 59-execution benchmark.

Preserves strict legacy metrics while separating ranking, acceptable-aware
semantic decisions, final multi-label promotion, and counterfactual direction.
"""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

def read_csv(path):
    with open(path,encoding='utf-8',newline='') as f: return list(csv.DictReader(f))
def split_ids(v): return [x.strip() for x in (v or '').split(';') if x.strip()]
def write_csv(path,rows,fields):
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
def top3(pred):
    try: return [x['SCR_ID'] for x in json.loads(pred.get('Top_Candidates_JSON') or '[]')[:3]]
    except Exception: return []
def raw_top3(pred):
    try: return [x['SCR_ID'] for x in json.loads(pred.get('Raw_Top_Candidates_JSON') or '[]')[:3]]
    except Exception: return []

def aggregate(rows,set_name):
    ready=[r for r in rows if r['Coverage_Status']=='RECOMMENDATION_EXECUTED']
    unresolved=[r for r in rows if r['Coverage_Status']!='RECOMMENDATION_EXECUTED']
    def yes(field): return sum(r.get(field)=='PASS' for r in ready)
    tp=sum(int(r.get('Promoted_TP') or 0) for r in ready); fp=sum(int(r.get('Promoted_FP') or 0) for r in ready); fn=sum(int(r.get('Promoted_FN') or 0) for r in ready)
    precision=tp/(tp+fp) if tp+fp else 1.0; recall=tp/(tp+fn) if tp+fn else 1.0; f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
    no_scr=[r for r in ready if not split_ids(r.get('Expected_SCR_IDs',''))]
    no_scr_fp=sum(r.get('No_SCR_Pass')=='FAIL' for r in no_scr)
    positive=[r for r in ready if split_ids(r.get('Expected_SCR_IDs',''))]
    multi=[r for r in positive if len(split_ids(r.get('Expected_SCR_IDs','')))>1]
    max_promoted=max((int(r.get('Promoted_Count') or 0) for r in ready),default=0)
    return {
      'benchmark_set':set_name,'execution_rows':len(rows),'recommendation_ready_rows':len(ready),'coverage_gap_rows':len(unresolved),
      'anchor_coverage_rate':len(ready)/len(rows) if rows else 0.0,
      # Legacy ranking metric retained for before/after comparability.
      'ready_row_overall_pass':yes('Overall_Recommendation_Pass'),'ready_row_overall_pass_rate':yes('Overall_Recommendation_Pass')/len(ready) if ready else 0.0,
      'top1_required_pass':yes('Top1_Required_Pass'),'top1_required_pass_rate':yes('Top1_Required_Pass')/len(ready) if ready else 0.0,
      'top3_required_set_pass':yes('Top3_Required_Set_Pass'),'top3_required_set_pass_rate':yes('Top3_Required_Set_Pass')/len(ready) if ready else 0.0,
      'raw_top3_required_set_pass':yes('Raw_Top3_Required_Set_Pass'),'raw_top3_required_set_pass_rate':yes('Raw_Top3_Required_Set_Pass')/len(ready) if ready else 0.0,
      # Design-7 semantic-decision and end-to-end metrics.
      'acceptable_aware_row_pass':yes('Acceptable_Aware_Row_Pass'),'acceptable_aware_row_pass_rate':yes('Acceptable_Aware_Row_Pass')/len(ready) if ready else 0.0,
      'strict_end_to_end_pass':yes('Strict_End_to_End_Pass'),'strict_end_to_end_pass_rate':yes('Strict_End_to_End_Pass')/len(ready) if ready else 0.0,
      'promoted_required_set_recovery':yes('Promoted_Required_Set_Pass'),'promoted_required_set_recovery_rate':yes('Promoted_Required_Set_Pass')/len(ready) if ready else 0.0,
      'exact_promoted_set_matches':yes('Exact_Promoted_Set_Match'),'exact_promoted_set_match_rate':yes('Exact_Promoted_Set_Match')/len(ready) if ready else 0.0,
      'promoted_set_tp':tp,'promoted_set_fp':fp,'promoted_set_fn':fn,'promoted_set_precision':precision,'promoted_set_recall':recall,'promoted_set_f1':f1,
      'ready_no_scr_rows':len(no_scr),'ready_no_scr_false_positive_rows':no_scr_fp,'unsupported_inference_rate_ready_rows':no_scr_fp/len(no_scr) if no_scr else 0.0,
      'positive_rows':len(positive),'multi_label_required_rows':len(multi),'multi_label_promotion_pass':sum(r.get('Multi_Label_Promotion_Pass')=='PASS' for r in multi),
      'multi_label_promotion_pass_rate':sum(r.get('Multi_Label_Promotion_Pass')=='PASS' for r in multi)/len(multi) if multi else None,
      'acceptable_aware_top1_pass_positive_rows':sum(r.get('Top1_Acceptable_Aware_Pass')=='PASS' for r in positive),
      'forbidden_top1_violations':sum(r.get('Forbidden_Top1_Pass')=='FAIL' for r in ready),'forbidden_promoted_violations':sum(r.get('Forbidden_Promoted_Pass')=='FAIL' for r in ready),
      'max_promoted_count':max_promoted,'rows_with_multiple_promoted_scrs':sum(int(r.get('Promoted_Count') or 0)>1 for r in ready),
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--predictions',required=True); ap.add_argument('--gold',required=True); ap.add_argument('--pairs',required=True); ap.add_argument('--out-dir',required=True)
    args=ap.parse_args(); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    preds=read_csv(args.predictions); gold_rows=read_csv(args.gold); gold={r['Test_ID']:r for r in gold_rows}; pred={r['Test_ID']:r for r in preds}
    eval_rows=[]
    for p in preds:
        g=gold[p['Test_ID']]; exp=set(split_ids(g.get('Expected_SCR_IDs',''))); acc=set(split_ids(g.get('Acceptable_SCR_IDs',''))); forb=set(split_ids(g.get('Forbidden_SCR_IDs','')))
        set_name=g.get('Benchmark_Set',''); ready=p['Coverage_Status']=='RECOMMENDATION_EXECUTED'
        common={'Test_ID':p['Test_ID'],'Benchmark_Set':set_name,'Case_Type':g['Case_Type'],'Coverage_Status':p['Coverage_Status'],
                'Expected_SCR_IDs':'; '.join(sorted(exp)),'Acceptable_SCR_IDs':'; '.join(sorted(acc)),'Forbidden_SCR_IDs':'; '.join(sorted(forb))}
        if not ready:
            eval_rows.append({**common,'Actual_Top1':'','Actual_Top3':'','Promoted_SCR_IDs':'','Promoted_Count':0,
                'Top1_Required_Pass':'NOT_EVALUABLE','Top1_Acceptable_Aware_Pass':'NOT_EVALUABLE','Top3_Required_Set_Pass':'NOT_EVALUABLE','Raw_Top3_Required_Set_Pass':'NOT_EVALUABLE',
                'Promoted_Required_Set_Pass':'NOT_EVALUABLE','Exact_Promoted_Set_Match':'NOT_EVALUABLE','Multi_Label_Promotion_Pass':'NOT_EVALUABLE',
                'Forbidden_Top1_Pass':'NOT_EVALUABLE','Forbidden_Promoted_Pass':'NOT_EVALUABLE','No_SCR_Pass':'NOT_EVALUABLE',
                'Acceptable_Aware_Row_Pass':'NOT_EVALUABLE','Overall_Recommendation_Pass':'NOT_EVALUABLE','Strict_End_to_End_Pass':'NOT_EVALUABLE',
                'Promoted_TP':0,'Promoted_FP':0,'Promoted_FN':0,'Mechanism_Gate':p['Mechanism_Gate'],'Decision_Status':p['Decision_Status']})
            continue
        top1=p.get('Recommended_SCR_ID','').strip(); t3=top3(p); rt3=raw_top3(p); promoted=set(split_ids(p.get('Promoted_SCR_IDs','')))
        if not promoted and top1: promoted={top1}
        if exp:
            t1=top1 in exp; t1acc=top1 in (exp|acc); t3p=exp.issubset(set(t3)); rt3p=exp.issubset(set(rt3)); pr=exp.issubset(promoted); noscr=False
            legacy_rowpass=t1 and t3p
            acceptable_row=t1acc
        else:
            t1=not bool(top1); t1acc=t1; t3p=not bool(t3); rt3p=not bool(rt3); pr=not bool(promoted); noscr=not bool(top1)
            legacy_rowpass=noscr; acceptable_row=noscr
        exact=promoted==exp; ftop=(top1 not in forb); fprom=not bool(promoted & forb)
        acceptable_row=acceptable_row and ftop
        strict_end=legacy_rowpass and pr and ftop and fprom
        multi=len(exp)>1; multi_pass=(pr and fprom) if multi else None
        tp=len(promoted&exp); fp=len(promoted-exp); fn=len(exp-promoted)
        eval_rows.append({**common,'Actual_Top1':top1,'Actual_Top3':'; '.join(t3),'Promoted_SCR_IDs':'; '.join(sorted(promoted)),'Promoted_Count':len(promoted),
            'Top1_Required_Pass':'PASS' if t1 else 'FAIL','Top1_Acceptable_Aware_Pass':'PASS' if t1acc else 'FAIL','Top3_Required_Set_Pass':'PASS' if t3p else 'FAIL','Raw_Top3_Required_Set_Pass':'PASS' if rt3p else 'FAIL',
            'Promoted_Required_Set_Pass':'PASS' if pr else 'FAIL','Exact_Promoted_Set_Match':'PASS' if exact else 'FAIL','Multi_Label_Promotion_Pass':('PASS' if multi_pass else 'FAIL') if multi else 'N/A',
            'Forbidden_Top1_Pass':('PASS' if ftop else 'FAIL') if forb else 'N/A','Forbidden_Promoted_Pass':('PASS' if fprom else 'FAIL') if forb else 'N/A',
            'No_SCR_Pass':(('PASS' if noscr else 'FAIL') if not exp else 'N/A'),'Acceptable_Aware_Row_Pass':'PASS' if acceptable_row else 'FAIL',
            'Overall_Recommendation_Pass':'PASS' if legacy_rowpass else 'FAIL','Strict_End_to_End_Pass':'PASS' if strict_end else 'FAIL',
            'Promoted_TP':tp,'Promoted_FP':fp,'Promoted_FN':fn,'Mechanism_Gate':p['Mechanism_Gate'],'Decision_Status':p['Decision_Status']})

    pairs=read_csv(args.pairs); eval_by={r['Test_ID']:r for r in eval_rows}; pair_rows=[]
    for pair in pairs:
        a,b=pair['Case A'],pair['Case B']; ea,eb=eval_by[a],eval_by[b]
        evaluable=ea['Coverage_Status']=='RECOMMENDATION_EXECUTED' and eb['Coverage_Status']=='RECOMMENDATION_EXECUTED'
        if evaluable:
            pa=pred[a].get('Promoted_SCR_IDs','') or pred[a].get('Recommended_SCR_ID',''); pb=pred[b].get('Promoted_SCR_IDs','') or pred[b].get('Recommended_SCR_ID','')
            changed=set(split_ids(pa))!=set(split_ids(pb))
            ranking_pair=changed and ea['Overall_Recommendation_Pass']=='PASS' and eb['Overall_Recommendation_Pass']=='PASS'
            exact_pair=changed and ea['Strict_End_to_End_Pass']=='PASS' and eb['Strict_End_to_End_Pass']=='PASS'
        else:
            changed=False; ranking_pair=False; exact_pair=False
        pair_rows.append({'Pair_ID':pair['Pair_ID'],'Benchmark_Set':pair.get('Benchmark_Set',''),'Case_A':a,'Case_B':b,'Evaluable':'YES' if evaluable else 'NO',
                          'Output_Changed':'YES' if changed else ('N/A' if not evaluable else 'NO'),
                          'Counterfactual_Direction_Pass':('PASS' if changed else 'FAIL') if evaluable else 'NOT_EVALUABLE_COVERAGE_GAP',
                          'Counterfactual_Ranking_Pair_Pass':('PASS' if ranking_pair else 'FAIL') if evaluable else 'NOT_EVALUABLE_COVERAGE_GAP',
                          'Counterfactual_Exact_Pair_Pass':('PASS' if exact_pair else 'FAIL') if evaluable else 'NOT_EVALUABLE_COVERAGE_GAP'})

    coverage_rows=[{'Test_ID':p['Test_ID'],'Benchmark_Set':gold[p['Test_ID']].get('Benchmark_Set',''),'Technical_Topic':p['Technical_Topic'],
                    'Preflight_Anchor_Status':p['Preflight_Anchor_Status'],'Preflight_Anchor_Type':p['Preflight_Anchor_Type'],'Preflight_Anchor_ID':p['Preflight_Anchor_ID'],'Coverage_Status':p['Coverage_Status']} for p in preds]
    sets={'CORE35_FROZEN':[r for r in eval_rows if r['Benchmark_Set']=='CORE35_FROZEN'],'CROSS_DOMAIN24_FROZEN':[r for r in eval_rows if r['Benchmark_Set']=='CROSS_DOMAIN24_FROZEN'],'ALL59':eval_rows}
    by_set={name:aggregate(rows,name) for name,rows in sets.items()}
    for name in by_set:
        relevant=[r for r in pair_rows if name=='ALL59' or r['Benchmark_Set']==name]; evp=[r for r in relevant if r['Evaluable']=='YES']
        by_set[name].update({
            'counterfactual_pairs_total':len(relevant),'counterfactual_pairs_evaluable':len(evp),
            'counterfactual_direction_pass':sum(r['Counterfactual_Direction_Pass']=='PASS' for r in evp),
            'counterfactual_direction_pass_rate':sum(r['Counterfactual_Direction_Pass']=='PASS' for r in evp)/len(evp) if evp else None,
            'counterfactual_ranking_pair_pass':sum(r['Counterfactual_Ranking_Pair_Pass']=='PASS' for r in evp),
            'counterfactual_ranking_pair_pass_rate':sum(r['Counterfactual_Ranking_Pair_Pass']=='PASS' for r in evp)/len(evp) if evp else None,
            'counterfactual_exact_pair_pass':sum(r['Counterfactual_Exact_Pair_Pass']=='PASS' for r in evp),
            'counterfactual_exact_pair_pass_rate':sum(r['Counterfactual_Exact_Pair_Pass']=='PASS' for r in evp)/len(evp) if evp else None,
        })
    metrics={'benchmark_units':52,'execution_rows':59,'benchmark_sets':by_set,
      'strict_primary_note':'Required-SCR Top-1/Top-3 metrics remain the primary ranking benchmark; original frozen gold is unchanged.',
      'acceptable_aware_note':'Acceptable_Aware_Row_Pass is a secondary semantic-decision metric: Top-1 may be Required or explicitly frozen Acceptable; multi-label completeness is still reported separately.',
      'end_to_end_note':'Strict_End_to_End_Pass requires legacy ranking pass plus recovery of every Required SCR in the final promoted set and no forbidden promotion.',
      'raw_top3_note':'Raw_Top3_Required_Set_Pass uses the unchanged global ranking before promoted secondaries are surfaced; this separates retrieval from promotion presentation.',
      'counterfactual_note':'Counterfactual direction (output changed), ranking-pair success, and exact/end-to-end pair success are reported separately.',
      'coverage_note':'Recommendation quality is reported on graph-ready rows; unresolved rows remain ontology/input-coverage gaps.'}
    metrics.update({k:v for k,v in by_set['ALL59'].items() if k!='benchmark_set'})
    write_csv(out/'evaluation_full_benchmark.csv',eval_rows,list(eval_rows[0])); write_csv(out/'coverage_report.csv',coverage_rows,list(coverage_rows[0])); write_csv(out/'counterfactual_evaluation.csv',pair_rows,list(pair_rows[0]))
    with open(out/'metrics_full_benchmark.json','w',encoding='utf-8') as f: json.dump(metrics,f,indent=2)
    print(json.dumps(metrics,indent=2))
if __name__=='__main__': main()
