#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from collections import defaultdict
from pathlib import Path

def read_csv(path):
    with open(path,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def write_csv(path,rows,fields):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def sset(s):return {x.strip() for x in (s or '').split(';') if x.strip()}
def top3(row):
    try:
        arr=json.loads(row.get('Top_Candidates_JSON') or '[]')
        return [x.get('SCR_ID','') for x in arr[:3] if x.get('SCR_ID')]
    except Exception:return []
def ctx_ids(row):
    try:
        arr=json.loads(row.get('Generated_Context_Candidates_JSON') or '[]')
        return [x.get('id','') for x in arr if x.get('id')]
    except Exception:return []

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--predictions',required=True);ap.add_argument('--gold',required=True);ap.add_argument('--context-quality-gold',required=True);ap.add_argument('--output-dir',required=True);args=ap.parse_args()
    pred={r['Test_ID']:r for r in read_csv(args.predictions)}
    gold=read_csv(args.gold)
    rows=[]; fam=defaultdict(list)
    for g in gold:
        p=pred[g['Test_ID']]
        req=sset(g['Expected_Required_SCR_IDs']);acc=sset(g['Acceptable_SCR_IDs']);forb=sset(g['Forbidden_SCR_IDs'])
        promoted=sset(p.get('Promoted_SCR_IDs'));t1=p.get('Recommended_SCR_ID','');t3=set(top3(p))
        route_ok=p.get('Routing_Status','')==g['Expected_Routing_Status']
        source_ok=(not g['Expected_Anchor_Source']) or p.get('Effective_Anchor_Source','')==g['Expected_Anchor_Source']
        at_ok=(not g['Expected_Anchor_Type']) or p.get('Effective_Anchor_Type','')==g['Expected_Anchor_Type']
        aid_ok=(not g['Expected_Anchor_ID']) or p.get('Effective_Anchor_ID','')==g['Expected_Anchor_ID']
        context_ok=(not g['Expected_Context_Source']) or p.get('Context_Source','')==g['Expected_Context_Source']
        gate_ok=(not g['Expected_Mechanism_Gate']) or p.get('Mechanism_Gate','')==g['Expected_Mechanism_Gate']
        elig_ok=p.get('Final_Recommendation_Eligible','')==g['Expected_Final_Recommendation_Eligible']
        top1_req=(not req) or t1 in req
        top1_aware=(not req) or t1 in (req|acc)
        top3_req=(not req) or req.issubset(t3)
        promo_req=(not req) or req.issubset(promoted)
        forb_ok=not bool(forb & promoted) and (t1 not in forb)
        no_scr_ok=(bool(req) or (not t1 and not promoted))
        context_candidate_ok=(g['Expected_Decision_Class']!='CONTEXT_REQUIRED') or (int(p.get('Generated_Context_Candidate_Count') or 0)>=1 and not t1)
        decision_class=g['Expected_Decision_Class']
        if decision_class=='RECOMMEND': decision_ok=bool(t1)
        elif decision_class=='ABSTAIN_NO_MECHANISM': decision_ok=(p.get('Decision_Status')=='ABSTAIN_NO_SUSTAINABILITY_MECHANISM' and not t1)
        elif decision_class=='CONTEXT_REQUIRED': decision_ok=context_candidate_ok
        else: decision_ok=(p.get('Execution_Status','').startswith('NOT_EXECUTED') and not t1)
        routing_bundle=all([route_ok,source_ok,at_ok,aid_ok,context_ok,gate_ok,elig_ok])
        recommendation_bundle=(promo_req and forb_ok and decision_ok) if decision_class=='RECOMMEND' else (no_scr_ok and decision_ok)
        e2e=routing_bundle and recommendation_bundle
        fam[g['Equivalence_Family']].append({
            'id':g['Test_ID'],'t1':t1,'promoted':';'.join(sorted(promoted)),'routing':p.get('Routing_Status',''),
            'top1_aware':top1_aware,'promo_req':promo_req,'decision_class':decision_class
        })
        rows.append({
            'Test_ID':g['Test_ID'],'Expected_Decision_Class':decision_class,
            'Routing_Status_Pass':'PASS' if route_ok else 'FAIL','Anchor_Source_Pass':'PASS' if source_ok else 'FAIL',
            'Anchor_Type_Pass':'PASS' if at_ok else 'FAIL','Anchor_ID_Pass':'PASS' if aid_ok else 'FAIL',
            'Context_Source_Pass':'PASS' if context_ok else 'FAIL','Mechanism_Gate_Pass':'PASS' if gate_ok else 'FAIL',
            'Eligibility_Pass':'PASS' if elig_ok else 'FAIL','Context_Candidate_Existence_Pass':'PASS' if context_candidate_ok else 'FAIL',
            'Actual_Top1':t1,'Actual_Top3':'; '.join(top3(p)),'Actual_Promoted_SCR_IDs':p.get('Promoted_SCR_IDs',''),
            'Top1_Required_Pass':'PASS' if top1_req else 'FAIL','Top1_Acceptable_Aware_Pass':'PASS' if top1_aware else 'FAIL',
            'Top3_Required_Set_Pass':'PASS' if top3_req else 'FAIL','Promoted_Required_Set_Pass':'PASS' if promo_req else 'FAIL',
            'Forbidden_Avoidance_Pass':'PASS' if forb_ok else 'FAIL','No_SCR_Pass':'PASS' if no_scr_ok else 'FAIL',
            'Decision_Class_Pass':'PASS' if decision_ok else 'FAIL','Routing_Bundle_Pass':'PASS' if routing_bundle else 'FAIL',
            'End_to_End_Pass':'PASS' if e2e else 'FAIL','Equivalence_Family':g['Equivalence_Family'],
            'Normalized_Application_Mechanism':p.get('Normalized_Application_Mechanism',''),
            'Normalized_Application_Facets_JSON':p.get('Normalized_Application_Facets_JSON','[]'),
        })

    eqrows=[]
    for family,items in fam.items():
        if not family.startswith('FAM_') or len(items)<2: continue
        tops={x['t1'] for x in items};promos={x['promoted'] for x in items}
        recitems=[x for x in items if x['decision_class']=='RECOMMEND']
        eqrows.append({
            'Equivalence_Family':family,'Member_Test_IDs':'; '.join(x['id'] for x in items),
            'Top1_Exact_Invariant':'PASS' if len(tops)==1 else 'FAIL',
            'Promoted_Set_Exact_Invariant':'PASS' if len(promos)==1 else 'FAIL',
            'All_Recommendation_Members_Top1_Acceptable_Aware':'PASS' if all(x['top1_aware'] for x in recitems) else 'FAIL',
            'All_Recommendation_Members_Required_Promoted':'PASS' if all(x['promo_req'] for x in recitems) else 'FAIL',
            'Observed_Top1s':' | '.join(sorted(tops)),'Observed_Promoted_Sets':' | '.join(sorted(promos))
        })

    cqrows=[]
    for g in read_csv(args.context_quality_gold):
        p=pred[g['Test_ID']]; ids=ctx_ids(p)
        high=sset(g['High_Relevance_Context_IDs']); acc=sset(g['Acceptable_Context_IDs']); off=sset(g['Clearly_Off_Scope_Context_IDs'])
        high_count=len(set(ids)&high); off_count=len(set(ids)&off)
        min_high=int(g['Min_High_Relevance_Count']);max_off=int(g['Max_Off_Scope_Count'])
        high_ok=high_count>=min_high; off_ok=off_count<=max_off
        cqrows.append({
            'Test_ID':g['Test_ID'],'Generated_Context_IDs':'; '.join(ids),
            'High_Relevance_Hit_Count':high_count,'Off_Scope_Hit_Count':off_count,
            'High_Relevance_Pass':'PASS' if high_ok else 'FAIL','Off_Scope_Avoidance_Pass':'PASS' if off_ok else 'FAIL',
            'Context_Candidate_Quality_Pass':'PASS' if high_ok and off_ok else 'FAIL',
            'Gold_Rationale':g['Gold_Rationale']
        })

    def rate(col,arr=rows):
        vals=[r for r in arr if r[col] in ('PASS','FAIL')]
        return sum(r[col]=='PASS' for r in vals)/len(vals) if vals else None
    recrows=[r for r in rows if r['Expected_Decision_Class']=='RECOMMEND']
    metrics={
        'execution_rows':len(rows),'routing_status_exact_rate':rate('Routing_Status_Pass'),'anchor_id_exact_rate':rate('Anchor_ID_Pass'),
        'context_source_exact_rate':rate('Context_Source_Pass'),'mechanism_gate_exact_rate':rate('Mechanism_Gate_Pass'),
        'routing_bundle_pass_rate':rate('Routing_Bundle_Pass'),'end_to_end_pass_rate':rate('End_to_End_Pass'),
        'recommendation_cases':len(recrows),'recommendation_top1_acceptable_aware_rate':rate('Top1_Acceptable_Aware_Pass',recrows),
        'recommendation_top3_required_rate':rate('Top3_Required_Set_Pass',recrows),'recommendation_promoted_required_rate':rate('Promoted_Required_Set_Pass',recrows),
        'negative_or_block_cases':sum(r['Expected_Decision_Class']!='RECOMMEND' for r in rows),
        'equivalence_families':len(eqrows),'equivalence_top1_exact_invariant_rate':rate('Top1_Exact_Invariant',eqrows),
        'equivalence_promoted_set_exact_invariant_rate':rate('Promoted_Set_Exact_Invariant',eqrows),
        'equivalence_semantic_top1_rate':rate('All_Recommendation_Members_Top1_Acceptable_Aware',eqrows),
        'equivalence_required_promotion_rate':rate('All_Recommendation_Members_Required_Promoted',eqrows),
        'context_candidate_quality_cases':len(cqrows),'context_candidate_quality_pass_rate':rate('Context_Candidate_Quality_Pass',cqrows),
        'context_candidate_high_relevance_rate':rate('High_Relevance_Pass',cqrows),'context_candidate_off_scope_avoidance_rate':rate('Off_Scope_Avoidance_Pass',cqrows),
    }
    Path(args.output_dir).mkdir(parents=True,exist_ok=True)
    write_csv(Path(args.output_dir)/'evaluation_educator_input_v2.csv',rows,list(rows[0]))
    write_csv(Path(args.output_dir)/'equivalence_evaluation_v2.csv',eqrows,list(eqrows[0]))
    write_csv(Path(args.output_dir)/'context_candidate_quality_evaluation_v1.csv',cqrows,list(cqrows[0]))
    with open(Path(args.output_dir)/'metrics_educator_input_v2.json','w',encoding='utf-8') as f:json.dump(metrics,f,indent=2)
    print(json.dumps(metrics,indent=2))
if __name__=='__main__':main()
