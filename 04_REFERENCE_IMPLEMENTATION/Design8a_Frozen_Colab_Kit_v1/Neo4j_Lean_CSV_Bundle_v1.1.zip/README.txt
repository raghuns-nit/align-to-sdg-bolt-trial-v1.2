Neo4j Lean CSV Bundle v1.1 — BOM-free runtime build
Source: Workbook1_Lean_Semantic_Enhanced_v1.1.xlsx plus unchanged framework repositories from v1.

Important fix:
- All CSV files are UTF-8 WITHOUT BOM.
- hybrid_runtime_v2.py reads CSV headers with encoding='utf-8', so a BOM in the first header causes KeyError such as '\ufeffcourse_id:ID'.

Counts:
- Full nodes: 9033
- Full relationships: 10347
- Relationship types: 22
- ApplicationContext nodes: 40
- Active SCR vocabulary unchanged (95 active; 96 rows including deprecated/merged)
