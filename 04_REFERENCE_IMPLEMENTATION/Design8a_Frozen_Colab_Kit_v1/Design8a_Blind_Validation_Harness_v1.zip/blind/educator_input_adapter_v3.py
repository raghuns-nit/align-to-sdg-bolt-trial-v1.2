#!/usr/bin/env python3
"""Educator Input Adapter v3 / Design-7.5b for the Recommendation System.

Purpose
-------
Route educator-facing inputs into the unchanged Design-7 recommendation runtime
without allowing free text to silently replace ontology scope.

This adapter is intentionally separate from the recommendation engine. It
handles:
  1) selected ontology anchor only;
  2) selected anchor + educator topic/context/question;
  3) educator text only (safe ontology resolution first);
  4) anchor/text mismatch, ambiguity and unresolved-text abstention;
  5) provenance of raw educator input and the effective context source.

The Design-7 runtime remains responsible for SCR ranking/promotion.
"""
from __future__ import annotations

import csv, json, os, re
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Tuple


def norm_text(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", (s or "").lower())).strip()


def read_csv(path: str) -> List[dict]:
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


@dataclass
class AdapterConfig:
    semantic_resolution_min: float = 0.58
    semantic_resolution_margin: float = 0.055
    generated_context_top_k: int = 2
    generated_context_min_quality: float = 0.18
    generated_context_exact_anchor_bonus: float = 0.18
    generated_context_token_bonus: float = 0.035


# Input eligibility gate v2 (preserved). It is deliberately stricter than the benchmark
# v1 gate: merely mentioning "sustainability" is not a mechanism.
EXPLICIT_NEGATIVE_PATTERNS = [
    r"\bno\b.+\b(sustainability|sustainable|objective|outcome|mechanism|context)\b",
    r"\bwithout\b.+\b(sustainability|objective|context|mechanism|outcome|threshold|feedback|corrective|governance)\b",
    r"\bonly\b.+\b(calculate|calculation|derive|definition|formula|head loss|friction factor|syntax|proof)\b",
]

MECHANISM_TERMS = [
    "leak", "water loss", "avoidable demand", "recharge", "infiltrat", "groundwater renewal",
    "pollution", "remediation", "externalit", "external cost", "life cycle", "lifecycle", "operating cost",
    "maintenance", "service life", "end-of-life", "labour criteria", "environmental criteria",
    "corrective action", "threshold", "monitor", "feedback", "reuse", "repair", "recycl",
    "virgin material", "resource", "emission", "energy", "waste", "equity", "access",
    "vulnerab", "resilien", "climate", "biodiversity", "ecosystem", "procurement", "supplier",
    "prevention", "control", "responsible operator", "fund prevention", "fund remediation",
]

ACTION_TERMS = [
    "reduce", "prevent", "restore", "increase", "improve", "fund", "require", "control",
    "remediate", "compare", "incorporate", "include", "charge", "price", "allocate", "target",
    "revise", "correct", "track", "monitor", "verify", "select", "recover", "extend", "shift",
    "avoid", "maintain", "manage", "influence", "design", "evaluate", "address", "identify", "introduce", "introduces", "influence", "influences",
]


def mechanism_gate_v2(text: str) -> Tuple[bool, str]:
    t = norm_text(text)
    if not t:
        return False, "NO_EDUCATOR_APPLICATION_CONTEXT"
    for pat in EXPLICIT_NEGATIVE_PATTERNS:
        if re.search(pat, t):
            return False, "EXPLICIT_ABSENCE_OR_TECHNICAL_ONLY"

    mech_hits = [x for x in MECHANISM_TERMS if norm_text(x) in t]
    action_hits = [x for x in ACTION_TERMS if norm_text(x) in t]

    # A bare label such as "sustainability considerations" is insufficient.
    if mech_hits and action_hits:
        return True, f"ACTION_AND_MECHANISM:{action_hits[0]}|{mech_hits[0]}"

    # Some phrases encode an intervention even when the verb is nominalized.
    strong_phrases = [
        "corrective action", "demand response", "environmental externality",
        "physical leakage", "groundwater recharge", "sustainable public procurement",
        "pollution liability", "fund prevention", "fund remediation",
    ]
    for phrase in strong_phrases:
        if norm_text(phrase) in t:
            return True, f"STRONG_MECHANISM_PHRASE:{phrase}"

    return False, "NO_EXPLICIT_ACTIONABLE_SUSTAINABILITY_MECHANISM"




# Design-7.5a: field-aware normalization of educator application evidence.
# Raw educator fields are preserved separately for provenance; only this normalized
# projection is passed to the unchanged Design-7 runtime.
QUESTION_LEADS = [
    r"^\s*how\s+can\s+", r"^\s*how\s+should\s+", r"^\s*how\s+does\s+",
    r"^\s*what\s+can\s+", r"^\s*what\s+should\s+", r"^\s*in\s+what\s+ways\s+can\s+",
]
COORDINATED_ACTION_WORDS = {
    "require","requires","required","fund","funds","reduce","reduces","increase","increases",
    "improve","improves","restore","restores","introduce","introduces","incorporate","incorporates",
    "compare","compares","consider","considers","include","includes","use","uses","apply","applies",
    "allocate","allocates","target","targets","monitor","monitors","correct","corrects","maintain","maintains",
    "extend","extends","prevent","prevents","control","controls","remediate","remediates","influence","influences",
    "want","wants","must","should","identify","identifies","select","selects","verify","verifies","assign","assigns",
}
CONTEXT_CONDITION_MARKERS = (
    "local ", "site ", "hydrogeolog", "ecolog", "climat", "seasonal", "boundary",
    "verified criteria", "analysis period", "life cycle", "lifecycle", "end-of-life",
)

def _clean_clause(s: str) -> str:
    s = re.sub(r"\s+", " ", (s or "")).strip(" ,.;?\t\n")
    return s

def _split_coordinated_actions(text: str) -> List[str]:
    """Conservatively split independent action-bearing clauses.

    This is intentionally not a general NLP parser. It only creates a stable
    mechanism projection for recommendation evidence; raw educator text remains
    the authoritative provenance record.
    """
    t=_clean_clause(text)
    if not t:
        return []
    # Preserve explicit coexistence/contrast markers as facet boundaries.
    parts=re.split(r"\s*;\s*|\s+\bwhile(?:\s+also)?\b\s+|\s+\bwhereas\b\s+|\s+\bwhilst\b\s+",t,flags=re.I)
    out=[]
    for part in parts:
        part=_clean_clause(part)
        if not part: continue
        # Split 'and <action verb>' only when the RHS clearly starts another action.
        toks=part.split()
        buf=[]
        for tok in toks:
            low=re.sub(r"[^a-z-]","",tok.lower())
            if low=="and" and buf:
                buf.append(tok)
                continue
            buf.append(tok)
        # regex handles the actual action-bearing conjunction split.
        action_alt="|".join(sorted(COORDINATED_ACTION_WORDS,key=len,reverse=True))
        subs=re.split(rf"\s+and\s+(?=(?:{action_alt})\b)",part,flags=re.I)
        for sub in subs:
            sub=_clean_clause(sub)
            if not sub: continue
            # 'using local/site/... conditions' is a distinct contextual-design facet.
            m=re.search(r"\s+using\s+(.+)$",sub,flags=re.I)
            if m and any(mark in m.group(1).lower() for mark in CONTEXT_CONDITION_MARKERS):
                left=_clean_clause(sub[:m.start()])
                right=_clean_clause("use "+m.group(1))
                if left: out.append(left)
                if right: out.append(right)
            else:
                out.append(sub)
    # ordered dedupe
    ded=[]; seen=set()
    for x in out:
        k=norm_text(x)
        if k and k not in seen and len(k.split())>=3:
            ded.append(x);seen.add(k)
    return ded

def normalize_application_evidence(context: str, question: str) -> dict:
    """Return a conservative field-aware runtime projection.

    Question-only behaviour is deliberately preserved because the frozen v1 MiniLM
    run already validated those forms. Context-only inputs receive conservative
    facet normalization. When both fields exist, they remain separate semantic
    facets rather than being concatenated into one sentence.
    """
    context=(context or "").strip(); question=(question or "").strip()
    field_facets=[]
    if context:
        cfacets=_split_coordinated_actions(context) or [_clean_clause(context)]
        for f in cfacets:
            if f: field_facets.append({"source":"CONTEXT","text":f})
    if question:
        # Keep validated question wording intact; Design-7 performs its own
        # conservative promotion-facet splitting (e.g. 'while ...').
        field_facets.append({"source":"QUESTION","text":_clean_clause(question)})
    ded=[];seen=set()
    for item in field_facets:
        k=norm_text(item["text"])
        if k and k not in seen:
            ded.append(item);seen.add(k)
    mechanism="; ".join(x["text"] for x in ded)
    boundary=[]
    for x in ded:
        if x["source"]!="CONTEXT":
            continue
        low=x["text"].lower()
        if any(m in low for m in ("local ","site ","hydrogeolog","seasonal","before ","without ","no ","excluded","analysis period")):
            boundary.append(x["text"])
    return {
        "facets":ded,
        "mechanism":mechanism,
        "boundary_conditions":"; ".join(boundary),
        "operational_action":question,
    }

def _content_tokens(s: str) -> set:
    stop={"the","and","for","with","from","into","of","to","in","on","a","an","or","using","use","system","systems","analysis","course","module","subtopic"}
    return {t for t in norm_text(s).split() if len(t)>=4 and t not in stop}


class EducatorInputAdapter:
    def __init__(self, runtime, cfg: AdapterConfig | None = None):
        self.rt = runtime
        self.cfg = cfg or AdapterConfig()

        self.course_by = runtime.course_by
        self.module_by = runtime.module_by
        self.sub_by = runtime.sub_by
        self.kcr_by = runtime.kcr_by
        self.kpr_by = runtime.kpr_by
        self.kfr_by = runtime.kfr_by

        # Parent maps from the graph.
        self.sub_to_module = {}
        self.module_to_course = {}
        for sid in self.sub_by:
            mid = next((src for tp, src in runtime.inn[sid] if tp == "CONTAINS_SUBTOPIC"), "")
            if mid:
                self.sub_to_module[sid] = mid
        for mid in self.module_by:
            cid = next((src for tp, src in runtime.inn[mid] if tp == "CONTAINS_MODULE"), "")
            if cid:
                self.module_to_course[mid] = cid

        self.node_types = {}
        self.node_names = {}
        for rows, idf, typ, namef in [
            (runtime.course, "course_id:ID", "Course", "title"),
            (runtime.module, "module_id:ID", "Module", "name"),
            (runtime.sub, "subtopic_id:ID", "Subtopic", "name"),
            (runtime.kcr, "kcr_id:ID", "KCR", "name"),
            (runtime.kpr, "kpr_id:ID", "KPR", "name"),
            (runtime.kfr, "kfr_id:ID", "KFR", "name"),
        ]:
            for r in rows:
                nid = r[idf]
                self.node_types[nid] = typ
                self.node_names[nid] = r.get(namef, "")

    def _course_nodes(self, cid: str) -> set:
        if cid not in self.course_by:
            return set()
        nodes = {cid}
        mids = [t for tp, t in self.rt.out[cid] if tp == "CONTAINS_MODULE"]
        nodes.update(mids)
        sids = []
        for mid in mids:
            ss = [t for tp, t in self.rt.out[mid] if tp == "CONTAINS_SUBTOPIC"]
            sids.extend(ss)
        nodes.update(sids)
        kids = []
        for sid in sids:
            ks = [t for tp, t in self.rt.out[sid] if tp == "MAPS_TO_KCR"]
            kids.extend(ks)
        nodes.update(kids)
        for kid in kids:
            nodes.update(src for tp, src in self.rt.inn[kid] if tp == "APPLIES_TO_KCR" and src in self.kpr_by)
            nodes.update(src for tp, src in self.rt.inn[kid] if tp == "ACTS_ON_KCR" and src in self.kfr_by)
        return nodes

    def _candidate_nodes(self, course_hint: str = "") -> List[str]:
        allowed_types = {"Course", "Module", "Subtopic", "KCR", "KPR", "KFR"}
        if course_hint:
            nodes = self._course_nodes(course_hint)
            return [n for n in nodes if self.node_types.get(n) in allowed_types and n in self.rt.texts]
        return [n for n, tp in self.node_types.items() if tp in allowed_types and n in self.rt.texts]

    def resolve_text_anchor(self, text: str, course_hint: str = "") -> dict:
        text = (text or "").strip()
        if not text:
            return {"status":"UNRESOLVED_ANCHOR", "reason":"NO_TEXT", "ranked":[]}

        candidates = self._candidate_nodes(course_hint)
        qn = norm_text(text)
        exact = [n for n in candidates if norm_text(self.node_names.get(n, "")) == qn]
        if exact:
            # Prefer a unique curricular location over its semantic KCR/KPR/KFR
            # representation. Multiple exact curricular locations remain
            # ambiguous unless a course hint narrows them.
            type_priority = ["Subtopic", "Module", "KCR", "KPR", "KFR", "Course"]
            chosen = None
            for tp in type_priority:
                same_type = [n for n in exact if self.node_types.get(n) == tp]
                if len(same_type) == 1:
                    chosen = same_type[0]
                    break
                if len(same_type) > 1:
                    return {
                        "status":"AMBIGUOUS_ANCHOR",
                        "reason":"MULTIPLE_EXACT_CURRICULAR_MATCHES",
                        "ranked":[{"id":n,"type":self.node_types[n],"name":self.node_names[n],"score":1.0} for n in exact[:10]],
                    }
            if chosen is None:
                return {
                    "status":"AMBIGUOUS_ANCHOR",
                    "reason":"MULTIPLE_EXACT_NAME_MATCHES",
                    "ranked":[{"id":n,"type":self.node_types[n],"name":self.node_names[n],"score":1.0} for n in exact[:10]],
                }
            n = chosen
            return {
                "status":"RESOLVED",
                "reason":"EXACT_CANONICAL_NAME",
                "type":self.node_types[n], "id":n, "score":1.0, "margin":1.0,
                "ranked":[{"id":n,"type":self.node_types[n],"name":self.node_names[n],"score":1.0}],
            }

        scores = self.rt.backend.similarity(text, candidates)
        ranked = sorted(scores.items(), key=lambda x:x[1], reverse=True)[:10]
        top_id, top_score = ranked[0] if ranked else ("",0.0)
        second = ranked[1][1] if len(ranked)>1 else 0.0
        margin = top_score-second
        trace=[{"id":n,"type":self.node_types[n],"name":self.node_names[n],"score":round(float(s),6)} for n,s in ranked]
        if top_score < self.cfg.semantic_resolution_min:
            return {"status":"UNRESOLVED_ANCHOR","reason":"LOW_SEMANTIC_CONFIDENCE","score":top_score,"margin":margin,"ranked":trace}
        if margin < self.cfg.semantic_resolution_margin:
            return {"status":"AMBIGUOUS_ANCHOR","reason":"LOW_TOP1_MARGIN","score":top_score,"margin":margin,"ranked":trace}
        return {
            "status":"RESOLVED","reason":"SEMANTIC_RESOLUTION",
            "type":self.node_types[top_id],"id":top_id,"score":top_score,"margin":margin,"ranked":trace,
        }

    def _anchor_exists(self, typ: str, ident: str) -> bool:
        maps = {
            "Course": self.course_by, "Module": self.module_by, "Subtopic": self.sub_by,
            "KCR": self.kcr_by, "KnowledgeConcept": self.kcr_by,
            "KPR": self.kpr_by, "KFR": self.kfr_by,
        }
        return ident in maps.get(typ, {})

    def _descendants_or_semantic_scope(self, typ: str, ident: str) -> set:
        out={ident}
        if typ == "Course":
            out.update(self._course_nodes(ident))
        elif typ == "Module":
            sids=[t for tp,t in self.rt.out[ident] if tp=="CONTAINS_SUBTOPIC"]
            out.update(sids)
            for sid in sids:
                out.update(t for tp,t in self.rt.out[sid] if tp=="MAPS_TO_KCR")
        elif typ == "Subtopic":
            out.update(t for tp,t in self.rt.out[ident] if tp=="MAPS_TO_KCR")
        elif typ in ("KCR","KnowledgeConcept"):
            out.update(src for tp,src in self.rt.inn[ident] if tp=="MAPS_TO_KCR")
        return out

    def _compatible_with_selected_anchor(self, selected_type: str, selected_id: str, resolved_type: str, resolved_id: str) -> bool:
        if selected_id == resolved_id:
            return True
        sel_scope=self._descendants_or_semantic_scope(selected_type,selected_id)
        res_scope=self._descendants_or_semantic_scope(resolved_type,resolved_id)
        return bool(sel_scope & res_scope)

    def _anchor_display_text(self, typ: str, ident: str) -> str:
        name=self.node_names.get(ident, ident)
        desc=self.rt.texts.get(ident, "")
        return (name + " " + desc).strip()

    def generate_context_candidates(self, typ: str, ident: str) -> List[dict]:
        """Generate cautious context suggestions from the technical anchor only.

        Design-7.5b preserves the Design-7.5a score but adds a compatibility gate:
        when the repository contains a context explicitly tagged to the selected
        anchor concept, zero-support semantic neighbours cannot enter the surfaced
        pool merely because MiniLM scores them highly. If no direct metadata match
        exists, the Design-7.5a semantic+metadata fallback is preserved.
        """
        query=self._anchor_display_text(typ,ident)
        semantic=self.rt.backend.similarity(query,self.rt.context_ids)
        anchor_name=self.node_names.get(ident,ident)
        atoks=_content_tokens(anchor_name)
        rows=[]
        for cid in self.rt.context_ids:
            c=self.rt.ctx_by[cid]
            meta=" ".join(str(c.get(k,"") or "") for k in ("name","application_domain","relevant_disciplines","keywords_synonyms"))
            mtoks=_content_tokens(meta)
            overlap=len(atoks & mtoks)
            exact=bool(norm_text(anchor_name) and norm_text(anchor_name) in norm_text(meta))
            bonus=(self.cfg.generated_context_exact_anchor_bonus if exact else 0.0) + self.cfg.generated_context_token_bonus*min(overlap,3)
            quality=float(semantic.get(cid,0.0))+bonus
            rows.append((cid,quality,float(semantic.get(cid,0.0)),overlap,exact))
        ranked=sorted(rows,key=lambda x:(x[1],x[2]),reverse=True)
        above=[r for r in ranked if r[1] >= self.cfg.generated_context_min_quality]

        # Design-7.5b compatibility gate. A direct anchor metadata match is
        # stronger evidence of applicability than dense semantic proximity.
        # If one or more direct matches exist, surface them first and admit an
        # additional candidate only when it has independent anchor metadata
        # support (token overlap > 0). This prevents a zero-support semantic
        # neighbour from displacing or accompanying a directly applicable
        # context. If no direct match exists, preserve the validated 7.5a
        # semantic+metadata fallback.
        direct=[r for r in above if r[4]]
        if direct:
            supported=[r for r in above if (not r[4]) and r[3] > 0]
            kept=(direct + supported)[:self.cfg.generated_context_top_k]
            gate_mode="DIRECT_ANCHOR_METADATA_GATE"
        else:
            kept=above[:self.cfg.generated_context_top_k]
            gate_mode="SEMANTIC_FALLBACK_NO_DIRECT_MATCH"

        return [
            {
                "id":cid,"name":self.rt.ctx_by[cid].get("name",""),
                "quality_score":round(q,6),"semantic_score":round(s,6),
                "anchor_token_overlap":ov,"exact_anchor_metadata_match":bool(ex),
                "compatibility_gate":gate_mode,
                "compatibility_support":"EXACT_ANCHOR_METADATA" if ex else ("ANCHOR_TOKEN_METADATA" if ov>0 else "SEMANTIC_FALLBACK")
            }
            for cid,q,s,ov,ex in kept
        ]

    def route(self, raw: dict) -> dict:
        selected_type=(raw.get("Selected_Anchor_Type") or "").strip()
        selected_id=(raw.get("Selected_Anchor_ID") or "").strip()
        course_hint=(raw.get("Course_Hint") or "").strip()
        topic=(raw.get("Educator_Topic_Text") or "").strip()
        context=(raw.get("Educator_Context_Text") or "").strip()
        question=(raw.get("Educator_Question_Text") or "").strip()

        provenance = {
            "Input_Mode":raw.get("Input_Mode",""),
            "Selected_Anchor_Type":selected_type,
            "Selected_Anchor_ID":selected_id,
            "Educator_Topic_Text_Raw":topic,
            "Educator_Context_Text_Raw":context,
            "Educator_Question_Text_Raw":question,
            "Course_Hint":course_hint,
        }

        # 1. Establish authoritative technical anchor.
        anchor_source=""
        resolution_trace=[]
        if selected_id:
            if not self._anchor_exists(selected_type,selected_id):
                return {**provenance,"Routing_Status":"INVALID_SELECTED_ANCHOR","Final_Recommendation_Eligible":"No"}
            eff_type,eff_id=selected_type,selected_id
            anchor_source="SYSTEM_SELECTION"
            if topic:
                tr=self.resolve_text_anchor(topic,"")
                resolution_trace=tr.get("ranked",[])
                mismatch_type = tr.get("type","")
                mismatch_id = tr.get("id","")
                mismatch_detected = False
                if tr.get("status") == "RESOLVED":
                    mismatch_detected = not self._compatible_with_selected_anchor(selected_type,selected_id,mismatch_type,mismatch_id)
                elif tr.get("status") == "AMBIGUOUS_ANCHOR" and resolution_trace:
                    # Ambiguous educator topic can still clearly contradict the
                    # selected anchor when its strongest global candidates are
                    # outside the selected technical scope.
                    top = resolution_trace[0]
                    mismatch_type, mismatch_id = top.get("type",""), top.get("id","")
                    top_score = float(top.get("score",0.0) or 0.0)
                    mismatch_detected = (
                        top_score >= self.cfg.semantic_resolution_min
                        and not self._compatible_with_selected_anchor(selected_type,selected_id,mismatch_type,mismatch_id)
                    )
                if mismatch_detected:
                    return {
                        **provenance,
                        "Routing_Status":"ANCHOR_TEXT_MISMATCH_REANCHOR",
                        "Effective_Anchor_Source":anchor_source,
                        "Effective_Anchor_Type":eff_type,
                        "Effective_Anchor_ID":eff_id,
                        "Text_Resolved_Anchor_Type":mismatch_type,
                        "Text_Resolved_Anchor_ID":mismatch_id,
                        "Anchor_Resolution_Trace_JSON":json.dumps(resolution_trace,ensure_ascii=False),
                        "Final_Recommendation_Eligible":"No",
                    }
        else:
            resolve_text=topic or question or context
            tr=self.resolve_text_anchor(resolve_text,course_hint)
            resolution_trace=tr.get("ranked",[])
            if tr.get("status") != "RESOLVED":
                return {
                    **provenance,
                    "Routing_Status":tr.get("status","UNRESOLVED_ANCHOR"),
                    "Anchor_Resolution_Reason":tr.get("reason",""),
                    "Anchor_Resolution_Score":round(float(tr.get("score",0.0)),6) if tr.get("score") is not None else "",
                    "Anchor_Resolution_Margin":round(float(tr.get("margin",0.0)),6) if tr.get("margin") is not None else "",
                    "Anchor_Resolution_Trace_JSON":json.dumps(resolution_trace,ensure_ascii=False),
                    "Final_Recommendation_Eligible":"No",
                }
            eff_type,eff_id=tr["type"],tr["id"]
            anchor_source="EDUCATOR_TEXT_RESOLUTION"

        # 2. Context precedence. Educator context/question always outranks generated context.
        educator_app_raw="; ".join(x for x in [context,question] if x).strip()
        if not educator_app_raw:
            candidates=self.generate_context_candidates(eff_type,eff_id)
            return {
                **provenance,
                "Routing_Status":"CONTEXT_SELECTION_REQUIRED",
                "Effective_Anchor_Source":anchor_source,
                "Effective_Anchor_Type":eff_type,
                "Effective_Anchor_ID":eff_id,
                "Context_Source":"SYSTEM_GENERATED_CANDIDATES",
                "Generated_Context_Candidates_JSON":json.dumps(candidates,ensure_ascii=False),
                "Generated_Context_Candidate_Count":len(candidates),
                "Generated_Context_Quality_Status":"CANDIDATES_AVAILABLE" if candidates else "NO_SAFE_CONTEXT_CANDIDATE",
                "Anchor_Resolution_Trace_JSON":json.dumps(resolution_trace,ensure_ascii=False),
                "Final_Recommendation_Eligible":"No",
            }

        context_source="EDUCATOR_CONTEXT"
        if question and not context:
            context_source="EDUCATOR_QUESTION"
        elif question and context:
            context_source="EDUCATOR_CONTEXT_PLUS_QUESTION"

        mech_present,gate_reason=mechanism_gate_v2(educator_app_raw)
        normalized=normalize_application_evidence(context,question)
        normalized_mechanism=normalized.get("mechanism") or educator_app_raw

        # Raw fields remain in provenance. Only the normalized mechanism projection
        # is passed to the unchanged Design-7 ranking/promotion runtime.
        technical_query = topic or self.node_names.get(eff_id, "")
        runtime_case={
            "Test_ID":raw.get("Test_ID",""),
            "Test_Dimension":"Educator Input Validation v2 / Design-7.5a",
            "Anchor_Type":eff_type,
            "Anchor_ID":eff_id,
            "Course_Hint":course_hint,
            "Technical_Query":technical_query,
            "Application_Context":normalized_mechanism,
            "Technical_System":self.node_names.get(eff_id, technical_query),
            "Operational_Action":normalized.get("operational_action", ""),
            "Mechanism":normalized_mechanism,
            "Affected_Resource_or_Function":"",
            "Stakeholder_or_Ecological_Context":"",
            "Boundary_Conditions":normalized.get("boundary_conditions", ""),
            "Sustainability_Mechanism_Present":"Yes" if mech_present else "No",
        }
        return {
            **provenance,
            "Routing_Status":"READY_FOR_RECOMMENDATION",
            "Effective_Anchor_Source":anchor_source,
            "Effective_Anchor_Type":eff_type,
            "Effective_Anchor_ID":eff_id,
            "Context_Source":context_source,
            "Effective_Application_Context":educator_app_raw,
            "Normalized_Application_Mechanism":normalized_mechanism,
            "Normalized_Application_Facets_JSON":json.dumps(normalized.get("facets",[]),ensure_ascii=False),
            "Normalized_Boundary_Conditions":normalized.get("boundary_conditions", ""),
            "Mechanism_Gate":"PASS" if mech_present else "BLOCK",
            "Mechanism_Gate_Reason":gate_reason,
            "Anchor_Resolution_Trace_JSON":json.dumps(resolution_trace,ensure_ascii=False),
            "Final_Recommendation_Eligible":"Yes",
            "Runtime_Case":runtime_case,
        }
