#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, os, re, sys
from pathlib import Path

def read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path, rows, fields):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader(); w.writerows(rows)

# Frozen, transparent eligibility preprocessor.
# It uses only the blind scenario text; it does not read gold labels.
POSITIVE_CUES = [
    "sustainab", "leak", "avoidable demand", "recharge", "infiltrat",
    "groundwater renewal", "restore", "traditional", "local condition",
    "hydrogeolog", "life extension", "extend service life", "premature failure",
    "condition-based maintenance", "degradation", "recovered material",
    "virgin material", "repair", "dismantl", "recovery", "peak",
    "demand response", "shift", "threshold", "corrective action", "trade-off",
    "organic matter", "affordable", "underserved", "low-income", "climate",
    "resource", "circular", "regenerat", "ecological", "governance", "equity",
    "access", "resilien", "adapt", "waste", "reuse", "recycle", "pollution",
    "emission", "environmental"
]
NEGATIVE_PATTERNS = [
    r"\bno\b.+\b(specified|objective|outcome|mechanism|context)\b",
    r"\bwithout\b.+\b(objective|context|mechanism|outcome|threshold|feedback|corrective|governance|energy-efficiency|resource-management)\b",
    r"\bunspecified\b",
    r"\bonly\b.+\b(cost|traffic performance|hydraulic capacity|reliability)\b",
    r"\bno sustainability objective\b",
]

def mechanism_gate(text):
    t=(text or "").lower()
    for p in NEGATIVE_PATTERNS:
        if re.search(p,t):
            return False, "EXPLICIT_ABSENCE_OR_EXCLUSION"
    hits=[x for x in POSITIVE_CUES if x in t]
    if hits:
        return True, "POSITIVE_MECHANISM_CUE:" + hits[0]
    return False, "NO_POSITIVE_SUSTAINABILITY_MECHANISM_CUE"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--runtime-dir", required=True)
    ap.add_argument("--repo-dir", required=True)
    ap.add_argument("--inputs", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--backend", default="sentence-transformer")
    ap.add_argument("--model-name", default="sentence-transformers/all-MiniLM-L6-v2")
    args=ap.parse_args()

    sys.path.insert(0,args.runtime_dir)
    from hybrid_runtime_v5 import HybridRuntime, RuntimeConfig

    class BenchmarkRuntime(HybridRuntime):
        # Input-adapter extension only: the preflight benchmark contains
        # defensible direct KCR anchors. Ranking/eligibility logic is unchanged.
        def _scope_kcrs(self, typ, ident):
            if typ in ("KCR","KnowledgeConcept"):
                return [ident] if ident in self.kcr_by else []
            return super()._scope_kcrs(typ,ident)

    rt=BenchmarkRuntime(args.repo_dir, RuntimeConfig(
        semantic_backend=args.backend, model_name=args.model_name
    ))

    blind=read_csv(args.inputs)
    outputs=[]
    ready_count=unresolved_count=0

    for b in blind:
        mech_present, gate_reason = mechanism_gate(b.get("SustainabilityCase",""))
        ready = b.get("Graph_Diagnostic_Readiness") == "READY"

        base = {
            "Test_ID": b["Test_ID"],
            "Discipline": b["Discipline"],
            "Technical_Topic": b["Technical_Topic"],
            "Benchmark_Application_Context": b["Application_Context"],
            "Benchmark_KFR_Action": b["KFR_Action"],
            "Benchmark_SustainabilityCase": b["SustainabilityCase"],
            "Preflight_Anchor_Status": b["Anchor_Status"],
            "Preflight_Anchor_Type": b["Anchor_Type"],
            "Preflight_Anchor_ID": b["Anchor_ID"],
            "Mechanism_Gate": "PASS" if mech_present else "BLOCK",
            "Mechanism_Gate_Reason": gate_reason,
        }

        if not ready:
            unresolved_count += 1
            out = {
                **base,
                "Coverage_Status":"UNRESOLVED_ANCHOR_REQUIRES_ONBOARDING",
                "Semantic_Backend":rt.backend.name,
                "Semantic_Backend_Version":rt.backend.version,
                "Embedding_Dimension":rt.backend.dimension,
                "Input_Anchor_Type":b["Anchor_Type"],
                "Input_Anchor_ID":b["Anchor_ID"],
                "Course_Hint":"",
                "Resolution_Type":"",
                "Resolution_ID":"",
                "Selected_KCR_IDs":"",
                "Evidence_Node_IDs":"",
                "Scope_Status":"UNRESOLVED_ANCHOR_REQUIRES_ONBOARDING",
                "Scope_Mismatch_Sibling":"",
                "Scope_Mismatch_Sibling_Score":"",
                "Direct_Anchor_Score":"",
                "Mechanism_Present":"Yes" if mech_present else "No",
                "Mechanism_Facets_JSON":"[]",
                "Top_Context_IDs":"",
                "Top_Context_Scores":"",
                "Recommended_SCR_ID":"",
                "Recommended_SCR_Name":"",
                "Promoted_SCR_IDs":"",
                "Decision_Status":"UNRESOLVED_ANCHOR_REQUIRES_ONBOARDING",
                "Top_Candidates_JSON":"[]",
                "Semantic_Anchor_Top_JSON":"[]",
            }
        else:
            ready_count += 1
            case = {
                "Test_ID":b["Test_ID"],
                "Test_Dimension":"Frozen 52-unit / 59-execution benchmark",
                "Anchor_Type":b["Anchor_Type"],
                "Anchor_ID":b["Anchor_ID"],
                "Course_Hint":"",
                "Technical_Query":b["Technical_Topic"],
                "Application_Context":b["Application_Context"],
                "Technical_System":b["Technical_Topic"],
                "Operational_Action":b["KFR_Action"],
                "Mechanism":b["SustainabilityCase"],
                "Affected_Resource_or_Function":"",
                "Stakeholder_or_Ecological_Context":"",
                "Boundary_Conditions":"",
                "Sustainability_Mechanism_Present":"Yes" if mech_present else "No",
            }
            pred=rt.predict(case)
            out={**base, "Coverage_Status":"RECOMMENDATION_EXECUTED", **pred}

        outputs.append(out)

    fields=list(outputs[0].keys())
    write_csv(args.output, outputs, fields)

    meta={
        "benchmark_release":"52-units-59-executions-FROZEN-v1",
        "runtime_release":"v5a-design8a-negation-aware-facet-promotion",
        "runtime_change_for_benchmark":"input adapter only: direct KCR anchors + preflight coverage blocking; Design-8a negation-aware secondary-promotion logic lives in runtime v5a",
        "semantic_backend":rt.backend.name,
        "semantic_backend_version":rt.backend.version,
        "embedding_dimension":rt.backend.dimension,
        "execution_rows":len(outputs),
        "recommendation_ready_rows":ready_count,
        "coverage_gap_rows":unresolved_count,
        "gold_read_during_prediction":False,
        "mechanism_gate":"frozen blind rule v1 using only SustainabilityCase text"
    }
    with open(args.output+".meta.json","w",encoding="utf-8") as f:
        json.dump(meta,f,indent=2)
    print(json.dumps(meta,indent=2))

if __name__=="__main__":
    main()
