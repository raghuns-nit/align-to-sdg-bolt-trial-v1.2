#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, os, sys
from pathlib import Path


def read_csv(path):
    with open(path,encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))

def write_csv(path,rows,fields):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--runtime-dir',required=True)
    ap.add_argument('--repo-dir',required=True)
    ap.add_argument('--adapter-file',required=True)
    ap.add_argument('--inputs',required=True)
    ap.add_argument('--output',required=True)
    ap.add_argument('--backend',default='sentence-transformer')
    ap.add_argument('--model-name',default='sentence-transformers/all-MiniLM-L6-v2')
    args=ap.parse_args()

    sys.path.insert(0,args.runtime_dir)
    from hybrid_runtime_v5 import HybridRuntime, RuntimeConfig

    adapter_dir=str(Path(args.adapter_file).resolve().parent)
    sys.path.insert(0,adapter_dir)
    from educator_input_adapter_v3 import EducatorInputAdapter

    class InputValidationRuntime(HybridRuntime):
        # Same compatibility adapter used in the frozen benchmark harness:
        # direct KCR is a safe technical anchor. Recommendation logic unchanged.
        def _scope_kcrs(self,typ,ident):
            if typ in ('KCR','KnowledgeConcept'):
                return [ident] if ident in self.kcr_by else []
            return super()._scope_kcrs(typ,ident)

    rt=InputValidationRuntime(args.repo_dir,RuntimeConfig(
        semantic_backend=args.backend,model_name=args.model_name
    ))
    adapter=EducatorInputAdapter(rt)
    inputs=read_csv(args.inputs)
    outputs=[]

    for raw in inputs:
        routed=adapter.route(raw)
        status=routed.get('Routing_Status','')

        if status in ('CONTEXT_SELECTION_REQUIRED',):
            coverage='RESOLVED'
            exec_status='NOT_EXECUTED_CONTEXT_REQUIRED'
        elif status=='READY_FOR_RECOMMENDATION':
            coverage='RESOLVED'
            exec_status='EXECUTED'
        elif status=='ANCHOR_TEXT_MISMATCH_REANCHOR':
            coverage='RESOLVED_SELECTED_ANCHOR_BUT_INPUT_CONFLICT'
            exec_status='NOT_EXECUTED_REANCHOR_REQUIRED'
        elif status=='AMBIGUOUS_ANCHOR':
            coverage='AMBIGUOUS_TEXT_ANCHOR'
            exec_status='NOT_EXECUTED_AMBIGUOUS_ANCHOR'
        elif status=='UNRESOLVED_ANCHOR':
            coverage='UNRESOLVED_TEXT_ANCHOR'
            exec_status='NOT_EXECUTED_UNRESOLVED_ANCHOR'
        else:
            coverage='INVALID_OR_BLOCKED_INPUT'
            exec_status='NOT_EXECUTED_ROUTING_BLOCK'

        base={
            'Test_ID':raw['Test_ID'],
            'Test_Group':raw.get('Test_Group',''),
            'Input_Mode':raw.get('Input_Mode',''),
            'Selected_Anchor_Type':raw.get('Selected_Anchor_Type',''),
            'Selected_Anchor_ID':raw.get('Selected_Anchor_ID',''),
            'Course_Hint':raw.get('Course_Hint',''),
            'Educator_Topic_Text_Raw':raw.get('Educator_Topic_Text',''),
            'Educator_Context_Text_Raw':raw.get('Educator_Context_Text',''),
            'Educator_Question_Text_Raw':raw.get('Educator_Question_Text',''),
            'Routing_Status':status,
            'Anchor_Coverage_Status':coverage,
            'Execution_Status':exec_status,
            'Effective_Anchor_Source':routed.get('Effective_Anchor_Source',''),
            'Effective_Anchor_Type':routed.get('Effective_Anchor_Type',''),
            'Effective_Anchor_ID':routed.get('Effective_Anchor_ID',''),
            'Text_Resolved_Anchor_Type':routed.get('Text_Resolved_Anchor_Type',''),
            'Text_Resolved_Anchor_ID':routed.get('Text_Resolved_Anchor_ID',''),
            'Anchor_Resolution_Reason':routed.get('Anchor_Resolution_Reason',''),
            'Anchor_Resolution_Score':routed.get('Anchor_Resolution_Score',''),
            'Anchor_Resolution_Margin':routed.get('Anchor_Resolution_Margin',''),
            'Anchor_Resolution_Trace_JSON':routed.get('Anchor_Resolution_Trace_JSON','[]'),
            'Context_Source':routed.get('Context_Source',''),
            'Effective_Application_Context':routed.get('Effective_Application_Context',''),
            'Normalized_Application_Mechanism':routed.get('Normalized_Application_Mechanism',''),
            'Normalized_Application_Facets_JSON':routed.get('Normalized_Application_Facets_JSON','[]'),
            'Normalized_Boundary_Conditions':routed.get('Normalized_Boundary_Conditions',''),
            'Generated_Context_Candidates_JSON':routed.get('Generated_Context_Candidates_JSON','[]'),
            'Generated_Context_Candidate_Count':routed.get('Generated_Context_Candidate_Count',0),
            'Generated_Context_Quality_Status':routed.get('Generated_Context_Quality_Status',''),
            'Mechanism_Gate':routed.get('Mechanism_Gate',''),
            'Mechanism_Gate_Reason':routed.get('Mechanism_Gate_Reason',''),
            'Final_Recommendation_Eligible':routed.get('Final_Recommendation_Eligible','No'),
            'Semantic_Backend':rt.backend.name,
            'Semantic_Backend_Version':rt.backend.version,
            'Embedding_Dimension':rt.backend.dimension,
        }

        if exec_status=='EXECUTED':
            pred=rt.predict(routed['Runtime_Case'])
            # Keep input-routing fields authoritative; append runtime trace with distinct names where needed.
            base.update({
                'Runtime_Input_Anchor_Type':pred.get('Input_Anchor_Type',''),
                'Runtime_Input_Anchor_ID':pred.get('Input_Anchor_ID',''),
                'Runtime_Resolution_Type':pred.get('Resolution_Type',''),
                'Runtime_Resolution_ID':pred.get('Resolution_ID',''),
                'Selected_KCR_IDs':pred.get('Selected_KCR_IDs',''),
                'Evidence_Node_IDs':pred.get('Evidence_Node_IDs',''),
                'Scope_Status':pred.get('Scope_Status',''),
                'Mechanism_Present':pred.get('Mechanism_Present',''),
                'Mechanism_Facets_JSON':pred.get('Mechanism_Facets_JSON','[]'),
                'Promotion_Facets_JSON':pred.get('Promotion_Facets_JSON','[]'),
                'Negative_Promotion_Facets_JSON':pred.get('Negative_Promotion_Facets_JSON','[]'),
                'Negation_Vetoed_SCR_IDs':pred.get('Negation_Vetoed_SCR_IDs',''),
                'Top_Context_IDs':pred.get('Top_Context_IDs',''),
                'Top_Context_Scores':pred.get('Top_Context_Scores',''),
                'Recommended_SCR_ID':pred.get('Recommended_SCR_ID',''),
                'Recommended_SCR_Name':pred.get('Recommended_SCR_Name',''),
                'Promoted_SCR_IDs':pred.get('Promoted_SCR_IDs',''),
                'Decision_Status':pred.get('Decision_Status',''),
                'Top_Candidates_JSON':pred.get('Top_Candidates_JSON','[]'),
            })
        else:
            base.update({
                'Runtime_Input_Anchor_Type':'','Runtime_Input_Anchor_ID':'',
                'Runtime_Resolution_Type':'','Runtime_Resolution_ID':'',
                'Selected_KCR_IDs':'','Evidence_Node_IDs':'','Scope_Status':'',
                'Mechanism_Present':'','Mechanism_Facets_JSON':'[]','Promotion_Facets_JSON':'[]','Negative_Promotion_Facets_JSON':'[]','Negation_Vetoed_SCR_IDs':'',
                'Top_Context_IDs':'','Top_Context_Scores':'','Recommended_SCR_ID':'',
                'Recommended_SCR_Name':'','Promoted_SCR_IDs':'','Decision_Status':'',
                'Top_Candidates_JSON':'[]',
            })
        outputs.append(base)

    fields=list(outputs[0].keys())
    write_csv(args.output,outputs,fields)
    meta={
        'suite_release':'educator-input-validation-v3-design7.5b-24-executions-as-design8-regression',
        'adapter_release':'educator-input-adapter-v3-design7.5b',
        'recommendation_runtime':'v5a-design8a-negation-aware-facet-promotion',
        'semantic_backend':rt.backend.name,
        'semantic_backend_version':rt.backend.version,
        'embedding_dimension':rt.backend.dimension,
        'execution_rows':len(outputs),
        'gold_read_during_prediction':False,
        'routing_policy':'selected ontology anchor controls technical scope; educator context/question is normalized into field-aware Application Mechanism facets; text-only must resolve to safe ontology anchor; system-only context candidates pass compatibility eligibility before semantic ranking; no educator application context -> candidates only, no final SCR',
        'terminology_note':'Coverage and execution are separate fields. EXECUTED means runtime ran; it does not imply recommendation correctness.'
    }
    with open(args.output+'.meta.json','w',encoding='utf-8') as f:
        json.dump(meta,f,indent=2)
    print(json.dumps(meta,indent=2))

if __name__=='__main__':
    main()
